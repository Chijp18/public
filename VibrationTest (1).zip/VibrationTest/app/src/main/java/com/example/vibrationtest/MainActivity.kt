package com.example.vibrationtest

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.MotionEvent
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var vibrator: Vibrator
    private lateinit var statusText: TextView
    private lateinit var durationLabel: TextView
    private lateinit var durationSeek: SeekBar
    private lateinit var intensityLabel: TextView
    private lateinit var intensitySeek: SeekBar

    // SeekBar は 0 始まりなので、最小 50ms を足して 50〜3000ms にする
    private val minDurationMs = 50
    private val maxDurationMs = 3000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        vibrator = getVibrator()

        statusText = findViewById(R.id.statusText)
        durationLabel = findViewById(R.id.durationLabel)
        durationSeek = findViewById(R.id.durationSeek)
        intensityLabel = findViewById(R.id.intensityLabel)
        intensitySeek = findViewById(R.id.intensitySeek)

        showDeviceStatus()

        // 強さは 1〜255 (SeekBar は 0 始まりなので +1)。強さ調整に対応した端末のみ有効
        intensitySeek.max = 254
        intensitySeek.progress = 254
        if (canControlAmplitude()) {
            updateIntensityLabel()
            intensitySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    updateIntensityLabel()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        } else {
            intensitySeek.isEnabled = false
            intensityLabel.text = getString(R.string.intensity_unsupported)
        }

        durationSeek.max = maxDurationMs - minDurationMs
        durationSeek.progress = 500 - minDurationMs
        updateDurationLabel()
        durationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateDurationLabel()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnShort).setOnClickListener {
            vibrateOnce(100)
        }
        findViewById<Button>(R.id.btnLong).setOnClickListener {
            vibrateOnce(1000)
        }
        findViewById<Button>(R.id.btnCustom).setOnClickListener {
            vibrateOnce(currentDurationMs().toLong())
        }
        findViewById<Button>(R.id.btnPattern).setOnClickListener {
            // 待機 → 振動 → 停止 を繰り返すパターン (ms)
            vibratePattern(longArrayOf(0, 200, 100, 200, 100, 400))
        }
        findViewById<Button>(R.id.btnSos).setOnClickListener {
            // 短×3、長×3、短×3
            vibratePattern(
                longArrayOf(
                    0,
                    150, 100, 150, 100, 150, 250,
                    450, 100, 450, 100, 450, 250,
                    150, 100, 150, 100, 150
                )
            )
        }
        // 押している間ずっと振動 (指を離す・画面外へ動かすと停止)
        findViewById<Button>(R.id.btnHold).setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> vibrateContinuous()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> vibrator.cancel()
            }
            // false を返してボタンの押下表示(波紋)をそのまま出す
            false
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            vibrator.cancel()
        }
    }

    override fun onPause() {
        super.onPause()
        vibrator.cancel()
    }

    private fun getVibrator(): Vibrator {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun showDeviceStatus() {
        statusText.text = if (!vibrator.hasVibrator()) {
            getString(R.string.status_unsupported)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator.hasAmplitudeControl()) {
            getString(R.string.status_supported_amplitude)
        } else {
            getString(R.string.status_supported)
        }
    }

    private fun canControlAmplitude(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            vibrator.hasVibrator() &&
            vibrator.hasAmplitudeControl()

    private fun currentIntensity(): Int = intensitySeek.progress + 1

    private fun updateIntensityLabel() {
        intensityLabel.text = getString(R.string.intensity_label, currentIntensity())
    }

    // 強さ調整に対応していない端末では端末任せのデフォルトの強さにする
    private fun currentAmplitude(): Int =
        if (canControlAmplitude()) currentIntensity() else VibrationEffect.DEFAULT_AMPLITUDE

    private fun currentDurationMs(): Int = durationSeek.progress + minDurationMs

    private fun updateDurationLabel() {
        durationLabel.text = getString(R.string.duration_label, currentDurationMs())
    }

    private fun vibrateOnce(durationMs: Long) {
        if (!vibrator.hasVibrator()) {
            statusText.text = getString(R.string.status_unsupported)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createOneShot(durationMs, currentAmplitude())
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(durationMs)
        }
    }

    // 停止されるまで振動し続ける (1秒の振動を繰り返す設定。止めるのは cancel())
    private fun vibrateContinuous() {
        if (!vibrator.hasVibrator()) {
            statusText.text = getString(R.string.status_unsupported)
            return
        }
        val timings = longArrayOf(0, 1000)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (canControlAmplitude()) {
                val amplitudes = intArrayOf(0, currentIntensity())
                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, 0))
            } else {
                vibrator.vibrate(VibrationEffect.createWaveform(timings, 0))
            }
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(timings, 0)
        }
    }

    private fun vibratePattern(pattern: LongArray) {
        if (!vibrator.hasVibrator()) {
            statusText.text = getString(R.string.status_unsupported)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // 繰り返し位置 -1 = 繰り返さない
            if (canControlAmplitude()) {
                // パターンは [待機, 振動, 待機, 振動, ...] の順なので、奇数番目だけ強さを指定する
                val amplitudes = IntArray(pattern.size) { i ->
                    if (i % 2 == 1) currentIntensity() else 0
                }
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, amplitudes, -1))
            } else {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            }
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
    }
}
