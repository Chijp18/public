# バイブレーションテスト

ボタンを押すと端末が振動する Android アプリです。

## 機能
- 短く振動 (100ms) / 長く振動 (1秒)
- パターン振動 / SOS パターン
- スライダーで長さを指定して振動 (50〜3000ms)
- 停止ボタン
- 振動非対応端末の検出

## APK の作り方

### 方法A: GitHub Actions(PCにAndroid Studio不要)
1. GitHub で新しいリポジトリを作り、このフォルダの中身をアップロード(`.github` フォルダも含める)
2. ブランチ名は `main` にする
3. 「Actions」タブ → 「Build APK」が自動で走る(数分)
4. 完了後、実行結果ページ下部の Artifacts から `VibrationTest-debug-apk` をダウンロード
5. zip を解凍して `app-debug.apk` をスマホへ送り、インストール

### 方法B: Android Studio
1. このフォルダを Android Studio で開く(Gradle 同期が自動で走る)
2. メニュー Build → Build APK(s)
3. 完了通知の「locate」から `app/build/outputs/apk/debug/app-debug.apk` を取得

## インストール時の注意
- 提供元不明のアプリを許可する設定が必要です(Chrome やファイルアプリに対して許可)
- 端末のマナーモードや「タッチ時の振動」設定、省電力設定によっては振動が弱くなる/鳴らないことがあります

## 動作環境
- Android 7.0 (API 24) 以上
