package com.example.vibrationtest

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var vibrator: Vibrator
    private lateinit var statusText: TextView
    private lateinit var durationLabel: TextView
    private lateinit var durationSeek: SeekBar

    // SeekBar は 0 始まりなので、最小 50ms を足して 50〜3000ms にする
    private val minDurationMs = 50
    private val maxDurationMs = 3000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        vibrator = getVibrator()

        statusText = findViewById(R.id.statusText)
        durationLabel = findViewById(R.id.durationLabel)
        durationSeek = findViewById(R.id.durationSeek)

        showDeviceStatus()

        durationSeek.max = maxDurationMs - minDurationMs
        durationSeek.progress = 500 - minDurationMs
        updateDurationLabel()
        durationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateDurationLabel()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnShort).setOnClickListener {
            vibrateOnce(100)
        }
        findViewById<Button>(R.id.btnLong).setOnClickListener {
            vibrateOnce(1000)
        }
        findViewById<Button>(R.id.btnCustom).setOnClickListener {
            vibrateOnce(currentDurationMs().toLong())
        }
        findViewById<Button>(R.id.btnPattern).setOnClickListener {
            // 待機 → 振動 → 停止 を繰り返すパターン (ms)
            vibratePattern(longArrayOf(0, 200, 100, 200, 100, 400))
        }
        findViewById<Button>(R.id.btnSos).setOnClickListener {
            // 短×3、長×3、短×3
            vibratePattern(
                longArrayOf(
                    0,
                    150, 100, 150, 100, 150, 250,
                    450, 100, 450, 100, 450, 250,
                    150, 100, 150, 100, 150
                )
            )
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            vibrator.cancel()
        }
    }

    override fun onPause() {
        super.onPause()
        vibrator.cancel()
    }

    private fun getVibrator(): Vibrator {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun showDeviceStatus() {
        statusText.text = if (!vibrator.hasVibrator()) {
            getString(R.string.status_unsupported)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator.hasAmplitudeControl()) {
            getString(R.string.status_supported_amplitude)
        } else {
            getString(R.string.status_supported)
        }
    }

    private fun currentDurationMs(): Int = durationSeek.progress + minDurationMs

    private fun updateDurationLabel() {
        durationLabel.text = getString(R.string.duration_label, currentDurationMs())
    }

    private fun vibrateOnce(durationMs: Long) {
        if (!vibrator.hasVibrator()) {
            statusText.text = getString(R.string.status_unsupported)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(durationMs)
        }
    }

    private fun vibratePattern(pattern: LongArray) {
        if (!vibrator.hasVibrator()) {
            statusText.text = getString(R.string.status_unsupported)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // 第2引数 -1 = 繰り返さない
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
    }
}
